import { world } from "@minecraft/server";
import { miningTracker } from "../../quests/mining/miningTracker";

world.afterEvents.playerBreakBlock.subscribe((e) => {
});
