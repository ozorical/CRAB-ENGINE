import { Player } from "@minecraft/server";

//* For If Ranks Become Selectable

export function rankSelector(player: Player) {}
