// import { Database } from "./Database";

// export const TABLES = {
//   test: new Database<any>("test"),
//   example: new Database<any>("example"),
// };
